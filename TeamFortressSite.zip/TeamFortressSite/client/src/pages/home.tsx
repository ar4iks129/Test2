import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Users, 
  Target, 
  Map, 
  Play, 
  Download, 
  Trophy, 
  Menu,
  ExternalLink
} from "lucide-react";
import { useState } from "react";
import tf2MapImage from "@assets/image_1755441969661.png";

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const gameStats = [
    { value: "50M+", label: "Активных игроков" },
    { value: "100+", label: "Уникальных карт" },
    { value: "15+", label: "Лет онлайн" },
    { value: "1000+", label: "Пользовательского контента" }
  ];

  const gameFeatures = [
    {
      icon: Users,
      title: "Командная игра",
      description: "Играйте в команде до 12 игроков. Координируйте действия, используйте стратегию и побеждайте вместе!",
      color: "tf-red"
    },
    {
      icon: Target,
      title: "9 уникальных классов",
      description: "От быстрого Разведчика до тяжелого Пулеметчика - найдите свой стиль игры среди разнообразных классов.",
      color: "tf-blue"
    },
    {
      icon: Map,
      title: "Множество карт",
      description: "Сражайтесь на десятках уникальных карт с различными режимами игры и тактическими возможностями.",
      color: "tf-orange"
    }
  ];

  const characterClasses = [
    {
      name: "Разведчик",
      description: "Быстрый и подвижный класс для фланговых атак",
      color: "tf-red",
      image: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
    },
    {
      name: "Солдат",
      description: "Универсальный боец с ракетным оружием",
      color: "tf-blue",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
    },
    {
      name: "Пулеметчик",
      description: "Танк команды с огромной огневой мощью",
      color: "tf-red",
      image: "https://pixabay.com/get/gf576846944289e3d01a262adf00e018e44eae4abddfcf17b91ad5a3bce715c30db09d57fe9720670ea91a5d79536133a8ca5a48c391f9732dd7d9c2b2eb49cb2_1280.jpg"
    },
    {
      name: "Подрывник",
      description: "Эксперт по взрывчатке и защите территории",
      color: "tf-blue",
      image: "https://images.unsplash.com/photo-1535350356005-fd52b3b524fb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
    },
    {
      name: "Инженер",
      description: "Строитель турелей и защитных сооружений",
      color: "tf-red",
      image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
    },
    {
      name: "Медик",
      description: "Целитель команды с уникальными способностями",
      color: "tf-blue",
      image: "https://pixabay.com/get/g2279673a3ad326c04ee218f14c1288126dd017a30e779105f8b253fa7fdcd30799f36cf09d705427a016d6668fa23f96534a3fc973b6d475d2b02aa416184ae3_1280.jpg"
    }
  ];

  const communityLinks = [
    {
      title: "Steam Workshop",
      description: "Скачивайте пользовательские карты, моды и оружие, созданные сообществом.",
      buttonText: "Открыть Workshop",
      color: "tf-red"
    },
    {
      title: "Discord сервер",
      description: "Общайтесь с игроками, ищите команду и участвуйте в турнирах.",
      buttonText: "Присоединиться",
      color: "tf-blue"
    },
    {
      title: "Турниры",
      description: "Участвуйте в соревнованиях и показывайте свои навыки на международной арене.",
      buttonText: "Узнать больше",
      color: "tf-orange"
    }
  ];

  return (
    <div className="min-h-screen bg-tf-dark text-white font-gaming overflow-x-hidden">
      {/* Header */}
      <header className="relative tf-gradient-header shadow-2xl">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-3xl font-black text-white">
                ТИМ ФОРТРЕС 2
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-white hover:text-tf-orange transition-colors duration-300 font-semibold">Главная</a>
              <a href="#" className="text-white hover:text-tf-orange transition-colors duration-300 font-semibold">Игра</a>
              <a href="#" className="text-white hover:text-tf-orange transition-colors duration-300 font-semibold">Классы</a>
              <a href="#" className="text-white hover:text-tf-orange transition-colors duration-300 font-semibold">Карты</a>
              <a href="#" className="text-white hover:text-tf-orange transition-colors duration-300 font-semibold">Сообщество</a>
              <Button className="bg-tf-orange hover:bg-orange-600 text-white px-6 py-2 rounded-lg font-bold transition-all duration-300 transform hover:scale-105">
                Играть сейчас
              </Button>
            </div>
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-white text-2xl"
              >
                <Menu className="h-6 w-6" />
              </Button>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat" 
          style={{
            backgroundImage: `linear-gradient(rgba(45, 45, 45, 0.7), rgba(45, 45, 45, 0.7)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')`
          }}
        />
        
        <div className="relative z-10 container mx-auto px-6 text-center">
          <h1 className="text-7xl md:text-9xl font-black mb-6 tf-text-gradient">
            TEAM FORTRESS 2
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-tf-light max-w-4xl mx-auto leading-relaxed">
            Присоединяйтесь к самой захватывающей командной битве! Выберите свой класс, объединитесь с командой и покажите противникам, кто здесь главный.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button className="bg-tf-red hover:bg-red-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-2xl">
              <Play className="mr-2 h-5 w-5" />
              Начать игру
            </Button>
            <Button className="bg-tf-blue hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-2xl">
              <Download className="mr-2 h-5 w-5" />
              Скачать бесплатно
            </Button>
          </div>
        </div>

        {/* Animated elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-tf-red rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute bottom-20 right-10 w-16 h-16 bg-tf-blue rounded-full opacity-20 animate-pulse"></div>
      </section>

      {/* Game Features */}
      <section className="py-20 bg-gradient-to-b from-tf-dark to-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-5xl font-black text-center mb-16 text-white">
            Особенности игры
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {gameFeatures.map((feature, index) => (
              <Card key={index} className={`bg-tf-dark border-2 border-${feature.color} rounded-xl p-8 hover:border-tf-orange transition-all duration-300 transform hover:scale-105`}>
                <CardContent className="pt-6">
                  <div className={`text-6xl text-${feature.color} mb-4`}>
                    <feature.icon className="h-16 w-16" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-white">{feature.title}</h3>
                  <p className="text-gray-300 leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 2Fort Image Section */}
      <section className="py-16 bg-gradient-to-b from-gray-900 to-gray-800">
        <div className="container mx-auto px-6">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-white mb-4">2Fort</h3>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Это одна из карт, которая вышла в релиз игры.
            </p>
          </div>
          <div className="flex justify-center">
            <img 
              src={tf2MapImage} 
              alt="2Fort - Team Fortress 2 Map" 
              className="rounded-xl shadow-2xl max-w-full h-auto border-4 border-tf-orange"
            />
          </div>
        </div>
      </section>

      {/* Character Classes */}
      <section className="py-20 bg-gradient-to-b from-gray-800 to-tf-dark">
        <div className="container mx-auto px-6">
          <h2 className="text-5xl font-black text-center mb-4 text-white">
            Выберите свой класс
          </h2>
          <p className="text-xl text-center text-gray-300 mb-16 max-w-3xl mx-auto">
            Каждый класс имеет уникальные способности, оружие и роль в команде. Найдите тот, который подходит именно вам!
          </p>
          
          <div className="grid md:grid-cols-3 lg:grid-cols-3 gap-6">
            {characterClasses.map((character, index) => (
              <Card key={index} className={`group bg-gradient-to-br from-${character.color} to-red-800 rounded-xl p-6 hover:from-tf-orange hover:to-orange-800 transition-all duration-300 transform hover:scale-105`}>
                <div 
                  className="w-full h-48 bg-cover bg-center rounded-lg mb-4" 
                  style={{ backgroundImage: `url('${character.image}')` }}
                />
                <h3 className="text-2xl font-bold mb-2 text-white">{character.name}</h3>
                <p className="text-red-100">{character.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Game Stats */}
      <section className="py-20 tf-gradient-hero">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-black mb-4 text-white">Team Fortress 2 сегодня</h2>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto">
              Присоединяйтесь к миллионам игроков по всему миру в этой легендарной игре
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            {gameStats.map((stat, index) => (
              <div key={index} className="text-center bg-black bg-opacity-30 rounded-xl p-8 backdrop-blur-sm">
                <div className="text-5xl font-black text-tf-orange mb-2">{stat.value}</div>
                <div className="text-white font-semibold">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section className="py-20 bg-gradient-to-b from-tf-dark to-gray-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-black mb-4 text-white">Присоединяйтесь к сообществу</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Станьте частью одного из самых активных игровых сообществ в мире
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {communityLinks.map((link, index) => (
              <Card key={index} className="bg-tf-dark border border-gray-700 rounded-xl p-8 hover:border-tf-orange transition-all duration-300">
                <CardContent className="pt-6">
                  <div className={`text-4xl text-${link.color} mb-4`}>
                    {index === 0 && <ExternalLink className="h-10 w-10" />}
                    {index === 1 && <Users className="h-10 w-10" />}
                    {index === 2 && <Trophy className="h-10 w-10" />}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-white">{link.title}</h3>
                  <p className="text-gray-300 mb-6">
                    {link.description}
                  </p>
                  <Button className={`bg-${link.color} hover:bg-red-700 text-white px-6 py-2 rounded-lg font-semibold transition-all duration-300`}>
                    {link.buttonText}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-tf-dark border-t border-gray-700 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-white mb-4">Team Fortress 2</h3>
              <p className="text-gray-400 mb-4">
                Легендарная командная игра от Valve Corporation. Играйте бесплатно!
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-tf-orange transition-colors">
                  <ExternalLink className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-tf-orange transition-colors">
                  <Play className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-tf-orange transition-colors">
                  <Users className="h-6 w-6" />
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Игра</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-tf-orange transition-colors">Скачать</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Системные требования</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Обновления</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Классы</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Сообщество</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-tf-orange transition-colors">Форумы</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Steam Workshop</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Турниры</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Гайды</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold text-white mb-4">Поддержка</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-tf-orange transition-colors">Техподдержка</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Баг-репорты</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Правила игры</a></li>
                <li><a href="#" className="hover:text-tf-orange transition-colors">Связаться с нами</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Valve Corporation. Team Fortress 2 и логотип Team Fortress являются торговыми марками Valve Corporation.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
