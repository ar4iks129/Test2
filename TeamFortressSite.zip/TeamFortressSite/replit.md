# Overview

This is a full-stack web application built with React frontend and Express.js backend, using a monorepo structure. The project appears to be a Team Fortress 2-themed gaming website or landing page with modern UI components. It uses TypeScript throughout, Tailwind CSS for styling, and shadcn/ui for component library. The application is configured for both development and production deployment with Vite as the build tool.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **Routing**: Wouter for client-side routing (lightweight React router alternative)
- **Styling**: Tailwind CSS with custom design system and shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Comprehensive shadcn/ui component system with Radix UI primitives
- **Form Handling**: React Hook Form with Zod validation resolvers

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Session-based authentication using connect-pg-simple for PostgreSQL session storage
- **API Design**: RESTful API structure with /api prefix routing

## Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database queries
- **Database**: PostgreSQL as primary database (configured for Neon Database serverless)
- **Schema**: Centralized schema definition in shared directory for type consistency
- **Migrations**: Drizzle Kit for database schema migrations and management

## Development Environment
- **Monorepo Structure**: Single repository with client, server, and shared code
- **Build System**: Vite for frontend bundling, esbuild for backend compilation
- **Development**: Hot reload for both frontend and backend in development mode
- **Type Safety**: Full TypeScript coverage across frontend, backend, and shared utilities

## Storage Layer
- **Primary Storage**: PostgreSQL database with Drizzle ORM
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **Development Storage**: In-memory storage fallback for development/testing
- **File Storage**: Static asset handling through Vite in development, Express in production

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting platform for production database
- **PostgreSQL**: Primary database system with full ACID compliance

## UI and Styling Libraries
- **Radix UI**: Unstyled, accessible UI primitives for complex components
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind
- **Lucide React**: Icon library for consistent iconography

## Development and Build Tools
- **Vite**: Frontend build tool and development server with HMR
- **esbuild**: Fast JavaScript bundler for backend compilation
- **Replit Integration**: Development environment plugins for Replit platform

## Authentication and Security
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **bcrypt**: Password hashing library (implied from user schema structure)

## Validation and Forms
- **Zod**: TypeScript-first schema declaration and validation library
- **React Hook Form**: Performant forms library with minimal re-renders
- **@hookform/resolvers**: Integration between React Hook Form and Zod validation

## Utility Libraries
- **date-fns**: Modern JavaScript date utility library
- **clsx & tailwind-merge**: Utility libraries for conditional className handling
- **nanoid**: URL-safe unique ID generator for sessions and tokens